package com.example.laba1_v6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import kotlin.math.pow

//Генерация случайных значений и запись в списки
val equation_one = mutableListOf<Int>(
    (0..100).random(),
    (0..100).random(),
    (0..10).random()
)

val equation_two = mutableListOf<Int>(
    (0..100).random(),
    (0..100).random(),
    (0..10).random()
)

class Polynomial {
    //Сохраним значения вычислений и в конце сложим
    private var summa: Double = 0.0

    fun get_summa(): Double { return summa }

    //Расчет полинома Ньютона
    fun newtons_binomial(x: Double, y: Double, lvl: Int): Double {
        val result: Double = (x + y).pow(lvl)
        summa += result
        return result
    }
}

class MainActivity : AppCompatActivity() {

    private lateinit var textView: TextView

    var obj = Polynomial()

    fun showRes (view: View) {
        obj.newtons_binomial(equation_one[0].toDouble(), equation_one[1].toDouble(), equation_one[2])
        obj.newtons_binomial(equation_two[0].toDouble(), equation_two[1].toDouble(), equation_two[2])
        textView.text = obj.get_summa().toString();
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textView = findViewById(R.id.textView2)
    }
}