package com.example.notepad

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.SearchView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.example.notepad.db.ListItem
import com.example.notepad.db.NoteAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    //val tvTest: TextView = findViewById(R.id.tvTest)
    //val edContent: EditText = findViewById(R.id.edTitle)
    val noteDbManager = com.example.notepad.db.NoteDbManager(this)
    val noteAdapter = NoteAdapter(ArrayList(), this)
    lateinit var rcView : RecyclerView
    lateinit var tvNoElements : TextView
    lateinit var searchView : SearchView
    lateinit var fbNew : FloatingActionButton
    lateinit var fbTrash : FloatingActionButton
    lateinit var curRcView : TextView
    var isTrash = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        init()
        initSearchView()
    }

    override fun onResume() {
        super.onResume()
        noteDbManager.openDb()
        fillAdapter()
    }

    override fun onDestroy(){
        super.onDestroy()
        noteDbManager.closeDb()
    }

    private fun onClickNew() {
        val edActivity = Intent(this,  EditActivity::class.java)
        startActivity(edActivity)
    }

    @SuppressLint("SetTextI18n")
    private fun onClickTrash() {
        fbNew = findViewById(R.id.fbNew)
        curRcView = findViewById(R.id.curRcView)
        if(isTrash == 1){
            isTrash = 0
            //fbNew.visibility = View.INVISIBLE
            fbNew.isClickable = false
            fbNew.backgroundTintList = ContextCompat.getColorStateList(this, R.color.gray)
            curRcView.text = "Trash"
        }else{
            isTrash = 1
            //fbNew.visibility = View.VISIBLE
            fbNew.isClickable = true
            fbNew.backgroundTintList = ContextCompat.getColorStateList(this, R.color.yel)
            curRcView.text = "Notes"
        }
        fillAdapter()
    }

    fun init(){
        rcView = findViewById(R.id.rcView)
        fbNew = findViewById(R.id.fbNew)
        fbTrash = findViewById(R.id.fbTrash)
        val swapHelper = getSwapMg()
        swapHelper.attachToRecyclerView(rcView)
        rcView.adapter = noteAdapter
        fbTrash.setOnClickListener {
            onClickTrash()
        }
        fbNew.setOnClickListener {
            onClickNew()
        }
    }

    fun fillAdapter(){
        tvNoElements = findViewById(R.id.tvNoElements)
        val list = noteDbManager.readDbData("", isTrash)
        noteAdapter.updateAdapter(list)
        if(list.size > 0)
            tvNoElements.visibility = View.GONE
        else
            tvNoElements.visibility = View.VISIBLE
    }

    fun initSearchView(){
        searchView = findViewById(R.id.searchView)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(p0: String?): Boolean {
                return true
            }

            override fun onQueryTextChange(text: String?): Boolean {
                val list = noteDbManager.readDbData(text!!, isTrash)
                noteAdapter.updateAdapter(list)
                return true
            }
        })
    }

    private fun getSwapMg() : ItemTouchHelper{
        return ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT){
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            @SuppressLint("NotifyDataSetChanged")
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                noteAdapter.removeItem(viewHolder.adapterPosition, noteDbManager)
                rcView.recycledViewPool.clear();
                noteAdapter.notifyDataSetChanged();
                fillAdapter()
            }
        })
    }
}