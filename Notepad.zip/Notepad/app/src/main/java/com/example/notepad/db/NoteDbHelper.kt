package com.example.notepad.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.example.notepad.db.NotepadDBClass.TABLE_NAME

class NoteDbHelper(context: Context) : SQLiteOpenHelper(context, NotepadDBClass.DATABASE_NAME, null, NotepadDBClass.DATABASE_VERSION) {
    override fun onCreate(db: SQLiteDatabase?) {
        Log.i("CREATE_TABLE", "On create")
        db?.execSQL(NotepadDBClass.CREATE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL(NotepadDBClass.SQL_DELETE_TABLE)
        // Drop old version table
        //db?.execSQL("Drop table $TABLE_NAME");
        onCreate(db)
    }
}