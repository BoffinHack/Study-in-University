package com.example.notepad.db

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.provider.BaseColumns


class NoteDbManager(context: Context) {
    val noteDbHelper = NoteDbHelper(context)
    var db: SQLiteDatabase? = null

    fun openDb(){
        db = noteDbHelper.writableDatabase
    }

    fun insertToDb(title: String, content: String, date: String, time: String, tag: Int){ //date: String
        val values = ContentValues().apply {
            put(NotepadDBClass.COLUMN_NAME_TITLE, title)
            put(NotepadDBClass.COLUMN_NAME_CONTENT, content)
            put(NotepadDBClass.COLUMN_NAME_DATE, date)
            put(NotepadDBClass.COLUMN_NAME_TIME, time)
            put(NotepadDBClass.COLUMN_NAME_TAG, tag)
        }
        db?.insert(NotepadDBClass.TABLE_NAME, null, values)
    }

    fun updateItem(title: String, content: String, id : Int, date: String, time: String){ //date: String
        val selection = BaseColumns._ID + "=$id"
        val values = ContentValues().apply {
            put(NotepadDBClass.COLUMN_NAME_TITLE, title)
            put(NotepadDBClass.COLUMN_NAME_CONTENT, content)
            put(NotepadDBClass.COLUMN_NAME_DATE, date)
            put(NotepadDBClass.COLUMN_NAME_TIME, time)
            //put(NotepadDBClass.COLUMN_NAME_TAG, tag)
        }
        db?.update(NotepadDBClass.TABLE_NAME, values, selection, null)
    }

    @SuppressLint("Recycle", "Range")
    fun removeItemFromDb(id: String){
        val selection = BaseColumns._ID + "=$id"
        val valuesTrue = ContentValues().apply {
            put(NotepadDBClass.COLUMN_NAME_TAG, 0)
        }
        val cursor = db?.query(NotepadDBClass.TABLE_NAME, null, null, null, null, null, null)
        while (cursor?.moveToNext()!!){
            val dataId = cursor.getInt(cursor.getColumnIndex(BaseColumns._ID))
            val dataTag = cursor.getInt(cursor.getColumnIndex(NotepadDBClass.COLUMN_NAME_TAG))
            if(dataId == id.toInt() && dataTag == 1){
                db?.update(NotepadDBClass.TABLE_NAME, valuesTrue, selection, null)
            }
            if(dataId == id.toInt() && dataTag == 0){
                db?.delete(NotepadDBClass.TABLE_NAME, selection, null)
            }
        }

        //val selection = BaseColumns._ID + "=$id"
        //db?.delete(NotepadDBClass.TABLE_NAME, selection, null)
    }

    @SuppressLint("Range")
    fun readDbData(searchText : String, tag : Int) : ArrayList<ListItem>{
        val dataList = ArrayList<ListItem>()
        val selection = "${NotepadDBClass.COLUMN_NAME_TITLE} like ?"
        val cursor = db?.query(NotepadDBClass.TABLE_NAME, null, selection, arrayOf("%$searchText%"), null, null, null)
        while (cursor?.moveToNext()!!){
            val dataTitle = cursor.getString(cursor.getColumnIndex(NotepadDBClass.COLUMN_NAME_TITLE))
            val dataContent = cursor.getString(cursor.getColumnIndex(NotepadDBClass.COLUMN_NAME_CONTENT))
            val dataId = cursor.getInt(cursor.getColumnIndex(BaseColumns._ID))
            val dataTime = cursor.getString(cursor.getColumnIndex(NotepadDBClass.COLUMN_NAME_TIME))
            val dataDate = cursor.getString(cursor.getColumnIndex(NotepadDBClass.COLUMN_NAME_DATE))
            val dataTag = cursor.getInt(cursor.getColumnIndex(NotepadDBClass.COLUMN_NAME_TAG))
            val item = ListItem()
            if(dataTag == tag){
                item.title = dataTitle
                item.cont = dataContent
                item.time = dataTime
                item.date = dataDate
                item.tag = dataTag
                item.id = dataId
                dataList.add(item)
            }
        }
        cursor.close()
        return dataList
    }

    fun closeDb(){
        noteDbHelper.close()
    }
}