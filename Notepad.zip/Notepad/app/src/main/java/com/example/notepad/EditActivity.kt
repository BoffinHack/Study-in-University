package com.example.notepad

import android.annotation.SuppressLint
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import androidx.annotation.RequiresApi
import com.example.notepad.db.NoteIntentConstans
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.text.SimpleDateFormat
import java.util.*

class EditActivity : AppCompatActivity() {
    lateinit var edTitle : EditText
    lateinit var edCont : EditText
    lateinit var fbSave : FloatingActionButton
    var id = 0
    var isEditState = false
    val noteDbManager = com.example.notepad.db.NoteDbManager(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.edit_activity)
        edTitle = findViewById(R.id.edTitle)
        edCont = findViewById(R.id.edCont)
        fbSave = findViewById(R.id.fbSave)
        getNoteIntents()
        initViews()
    }

    override fun onResume() {
        super.onResume()
        noteDbManager.openDb()
    }

    override fun onDestroy(){
        super.onDestroy()
        noteDbManager.closeDb()
    }

    private fun initViews() {
        fbSave.setOnClickListener{
            onClickSave()
        }
    }

    private fun onClickSave() {
        //SimpleDateFormat("dd/M/yyyy")SimpleDateFormat("dd/M/yyyy").format(Date()
        if(edTitle.text.toString() != "" && edCont.text.toString() != ""){
            if(isEditState){
                noteDbManager.updateItem(edTitle.text.toString(), edCont.text.toString(), id, getCurrentDate(), getCurrentTime()) //SimpleDateFormat("dd.M.yyyy").format(Date())
            }else{
                noteDbManager.insertToDb(edTitle.text.toString(), edCont.text.toString(), getCurrentDate(), getCurrentTime(), 1) //SimpleDateFormat("dd.M.yyyy").format(Date())
            }
            finish()
        }
    }

    fun getNoteIntents(){
        val i = intent
        if(i.getStringExtra(NoteIntentConstans.I_TITLE_KEY) != null){
            isEditState = true
            edTitle.setText(i.getStringExtra(NoteIntentConstans.I_TITLE_KEY))
            edCont.setText(i.getStringExtra(NoteIntentConstans.I_CONT_KEY))
            id = i.getIntExtra(NoteIntentConstans.I_ID_KEY, 0)
        }
    }

    private fun getCurrentDate(): String {
        val pattern = "dd.MM.yy"
        val time = Calendar.getInstance().time
        val formatter = SimpleDateFormat(pattern, Locale.getDefault()).format(Date())
        return formatter.format(time)
    }

    private fun getCurrentTime(): String {
        val pattern = "kk:mm"
        val time = Calendar.getInstance().time
        val formatter = SimpleDateFormat(pattern, Locale.getDefault()).format(Date())
        return formatter.format(time)
    }
}