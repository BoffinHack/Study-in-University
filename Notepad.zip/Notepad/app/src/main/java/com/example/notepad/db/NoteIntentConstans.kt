package com.example.notepad.db

object NoteIntentConstans {
    const val I_TITLE_KEY = "title_key"
    const val I_CONT_KEY = "cont_key"
    const val I_ID_KEY = "id_key"
}