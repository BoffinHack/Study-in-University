package com.example.notepad.db

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.notepad.EditActivity
import com.example.notepad.MainActivity
import com.example.notepad.R

class NoteAdapter(listMain: ArrayList<ListItem>, contextM: MainActivity) : RecyclerView.Adapter<NoteAdapter.NoteHolder>() {
    var listArray = listMain
    var context = contextM

    class NoteHolder(itemView: View, contextV: Context) : RecyclerView.ViewHolder(itemView) {
        var tvTitle : TextView = itemView.findViewById(R.id.tvTitle)
        var tvDate : TextView = itemView.findViewById(R.id.tvDate)
        var tvTime : TextView = itemView.findViewById(R.id.tvTime)
        var context = contextV
        fun setData(item : ListItem){
            tvTitle.text = item.title
            tvDate.text = item.date
            tvTime.text = item.time
            itemView.setOnClickListener(){
                val intent = Intent(context, EditActivity::class.java).apply {
                    putExtra(NoteIntentConstans.I_TITLE_KEY, item.title)
                    putExtra(NoteIntentConstans.I_CONT_KEY, item.cont)
                    putExtra(NoteIntentConstans.I_ID_KEY, item.id)
                }
                context.startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteHolder {
        val inflater = LayoutInflater.from(parent.context)
        return NoteHolder((inflater.inflate(R.layout.rc_item, parent, false)), context)
    }

    override fun onBindViewHolder(holder: NoteHolder, position: Int) {
        holder.setData(listArray.get(position))
    }

    override fun getItemCount(): Int {
        return listArray.size
    }

    @SuppressLint("NotifyDataSetChanged")
    fun updateAdapter(listIems : List<ListItem>){
        listArray.clear()
        listArray.addAll(listIems)
        notifyDataSetChanged()
    }

    fun removeItem(pos:Int, dbManager: NoteDbManager){
        dbManager.removeItemFromDb(listArray[pos].id.toString())
        listArray.removeAt(pos)
        notifyItemChanged(0, listArray.size)
        notifyItemChanged(pos)
    }
}