package com.example.notepad.db

class ListItem {
    var id = 0
    var title = "empty"
    var cont = "empty"
    var time = "empty"
    var date = "empty"
    var tag = 1
}